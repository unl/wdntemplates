tinyMCEPopup.requireLangPack();

var UnlGridDialog = {
	init : function(ed) {
		this.editor = ed;
	},

	submit : function() {
		var ed = this.editor, elm, values = document.forms[0].gridValues.value;
		var selection = tinyMCEPopup.editor.selection;
		var grid = values.split(',');

		tinyMCEPopup.restoreSelection();

		elm = ed.dom.getParent(ed.selection.getNode(), 'P');

		if (elm) {
			ed.dom.remove(elm);
		}

		var newContent = '<div class="grid'+grid[0]+' first">' + selection.getContent() + '&nbsp;</div>';

		for (var i=1;i<grid.length;i++) {
			newContent = newContent + '<div class="grid'+grid[i]+'">&nbsp;</div>';
		}

		newContent = '<p>&nbsp;</p>' + newContent + '<p class="clear">&nbsp;</p>';

		selection.setContent(newContent);

		tinyMCEPopup.close();
		return false;
	}
};

tinyMCEPopup.onInit.add(UnlGridDialog.init, UnlGridDialog);
