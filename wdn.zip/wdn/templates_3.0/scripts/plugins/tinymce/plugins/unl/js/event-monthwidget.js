tinyMCEPopup.requireLangPack();

var UnlMonthWidgetDialog = {

	init : function() {
		var selection = tinyMCEPopup.editor.selection;
		var node = selection.getNode();
		if (node && node.id == 'monthwidget') {
			var matches = selection.getContent().match(/UNLevent_monthWidget\.init\(([^)]*)\)/i);
			var calendarUri = matches[1].substr(1, matches[1].length - 2);
			document.getElementById('unlEventUri').value = calendarUri;
			UnlMonthWidgetDialog.calendarUri = calendarUri;
		}

		document.getElementById('unlEventMonthWidgetForm').onsubmit = UnlMonthWidgetDialog.submit;
	},

	submit : function() {
		var selection = tinyMCEPopup.editor.selection;
		var eventUri = document.getElementById('unlEventUri').value;
		var node = selection.getNode();
		
		if (node && node.id == 'monthwidget') {
			var html = selection.getContent()
			selection.setContent(html.replace(UnlMonthWidgetDialog.calendarUri, eventUri));
		} else {
			selection.setContent("<div id=\"monthwidget\"><script type=\"text/javascript\">function getElementsByClass(node,searchClass,tag) {return WDN.jQuery(tag+'.'+searchClass, node);} WDN.loadCSS('http://www.unl.edu/ucomm/templatedependents/templatecss/components/monthwidget.css'); WDN.loadJS('http://www.unl.edu/ucomm/templatedependents/templatesharedcode/scripts/UNLevent_monthWidget.js', function() {UNLevent_monthWidget.init('" + eventUri + "');});</script></div>");
		}
		
		tinyMCEPopup.close();
		return false;
	},
	
	calendarUri : ''
};

tinyMCEPopup.onInit.add(UnlMonthWidgetDialog.init, UnlMonthWidgetDialog);
