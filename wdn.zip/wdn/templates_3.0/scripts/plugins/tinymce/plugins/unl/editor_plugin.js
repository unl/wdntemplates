/**
 * plugins/unl/editor_plugin.js
 */

var Unl = {};

Unl.hasParentNodeWithClass = function(childNode, parentClass) {
	for (var selectedNode = childNode; selectedNode.id != 'maincontent'; selectedNode = selectedNode.parentNode) {
		if (selectedNode.className.search(parentClass) >= 0) {
			return selectedNode;
		}
	}
	return false;
};

(function() {
	var mceUnlBaseUrl;
	var addClass = function(element, className) {
		if (element.className.search(className) >= 0) {
			return;
		}
		if (element.className.length > 0) {
			element.className += ' ' + className;
		} else {
			element.className = className;
		}
	};

	// Load plugin specific language pack
	//tinymce.PluginManager.requireLangPack('unl');

	tinymce.create('tinymce.plugins.UnlPlugin', {
		/**
		 * Initializes the plugin, this will be executed after the plugin has been created.
		 * This call is done before the editor instance has finished it's initialization so use the onInit event
		 * of the editor instance to intercept that event.
		 *
		 * @param {tinymce.Editor} ed Editor instance that the plugin is initialized in.
		 * @param {string} url Absolute URL to where the plugin is located.
		 */
		init : function(ed, url) {
			mceUnlBaseUrl = url;

			//'div[style]/[*]';
			ed.onBeforeSetContent.add(function(ed, o) {
				ed.dom.loadCSS("/wdn/templates_3.0/css/all.css");
				ed.getBody().className += ' fixed';
				ed.getBody().id = 'maincontent';
			});

			/*ed.onPostProcess.add(function(ed, o) {
				var links = ed.getBody().getElementsByTagName('a');
				for (var i = 0; i < links.length; i++) {
					var link = links[i];
					var href = link.getAttribute('href');

					if (!href) {
						continue;
					}

					// add icons to links via UNL template
					if (href.search(/^mailto:/) >= 0 ) {
						addClass(link, 'email');
					}
					if (href.search(/\.(vcf)|(vcard)$/) >= 0) {
						addClass(link, 'text-vcard');
					}
					if (href.search(/\.pdf$/) >= 0) {
						addClass(link, 'application-pdf');
					}
					if (href.search(/\.crt$/) >= 0 ) {
						addClass(link, 'application-certificate');
					}
					if (href.search(/\.exe$/) >= 0 ) {
						addClass(link, 'application-x-executable');
					}
					if (href.search(/\.(mp3)|(wav)|(wma)|(aac)$/) >= 0 ) {
						addClass(link, 'audio-x-generic');
					}
					if (href.search(/\.ttf$/) >= 0 ) {
						addClass(link, 'font-x-generic');
					}
					if (href.search(/\.(jpg)|(jpeg)|(gif)|(png)|(bmp)$/) >= 0 ) {
						addClass(link, 'image-x-generic');
					}
					if (href.search(/\.(pkg)|(msi)$/) >= 0 ) {
						addClass(link, 'package-x-generic');
					}
					if (href.search(/\.(txt)|(rtf)$/) >= 0 ) {
						addClass(link, 'text-x-generic');
					}
					if (href.search(/\.(mov)|(wmv)|(mp4)|(m4v)|(avi)|(mkv)|(mpg)|(mpeg)$/) >= 0 ) {
						addClass(link, 'video-x-generic');
					}
					if (href.search(/\.(ical)|(ics)|(ifb)|(icalendar)$/) >= 0 ) {
						addClass(link, 'x-office-calendar');
					}
					if (href.search(/\.odt$/) >= 0 ) {
						addClass(link, 'x-office-document');
					}
					if (href.search(/\.odg$/) >= 0 ) {
						addClass(link, 'x-office-drawing');
					}
					if (href.search(/\.odp$/) >= 0 ) {
						addClass(link, 'x-office-presentation');
					}
					if (href.search(/\.ods$/) >= 0 ) {
						addClass(link, 'x-office-spreadsheet');
					}
					if (href.search(/\.(doc)|(docx)$/) >= 0 ) {
						addClass(link, 'msword');
					}
					if (href.search(/\.(xls)|(xlsx)$/) >= 0 ) {
						addClass(link, 'application-vnd-ms-excel');
					}
					if (href.search(/\.(ppt)|(pptx)|(pps)$/) >= 0 ) {
						addClass(link, 'application-vnd-ms-powerpoint');
					}
					if (href.search(/\.(zip)|(gz)|(bz2)|(Z)|(7z)|(sit)|(cab)$/) >= 0 ) {
						addClass(link, 'application-zip');
					}
					if (href.search(/\.(rss)|(atom)$/) >= 0 ) {
						addClass(link, 'feed-icon');
					}
					if (href.search(/^[a-zA-Z]*:\/\//) >= 0) {
						addClass(link, 'external');
					}
				}
			});*/

			// Register the command so that it can be invoked by using tinyMCE.activeEditor.execCommand('mceUnl');
			ed.addCommand('mceUnl', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div class="zenbox bright"><h3>Title</h3><p>Body</p></div> <div><img src="http://wdn.unl.edu/graphics/image_templates/image_tag_ex.jpg" class="frame" /><p class="caption">Caption goes here</p></div> <p></p>');
			});

			// Zenbox
			ed.addCommand('mceUnlZenBoxBright', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div class="zenbox bright"><h3>Title</h3><p>Body</p></div>');
			});
			ed.addCommand('mceUnlZenBoxCool', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div class="zenbox cool"><h3>Title</h3><p>Body</p></div>');
			});
			ed.addCommand('mceUnlZenBoxEnergetic', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div class="zenbox energetic"><h3>Title</h3><p>Body</p></div>');
			});
			ed.addCommand('mceUnlZenBoxSoothing', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div class="zenbox soothing"><h3>Title</h3><p>Body</p></div>');
			});
			ed.addCommand('mceUnlZenBoxPrimary', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div class="zenbox primary"><h3>Title</h3><p>Body</p></div>');
			});
			ed.addCommand('mceUnlZenBoxNeutral', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div class="zenbox neutral"><h3>Title</h3><p>Body</p></div>');
			});

			// UNL Layout
			ed.addCommand('mceUnlCol13', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div>Placeholder</div><div class="col left"><p>Left Column Placeholder</p></div><div class="three_col right"><p>Right Column Placeholder</p></div><div class="clear"></div><div>Placeholder</div>');
			});
			ed.addCommand('mceUnlCol22', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div>Placeholder</div><div class="two_col left"><p>Left Column Placeholder</p></div><div class="two_col right"><p>Right Column Placeholder</p></div><br class="clear" /><div>Placeholder</div>');
			});
			ed.addCommand('mceUnlCol31', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div>Placeholder</div><div class="three_col left"><p>Left Column Placeholder</p></div><div class="col right"><p>Right Column Placeholder</p></div><br class="clear" /><div>Placeholder</div>');
			});
			ed.addCommand('mceUnlCol112', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div>Placeholder</div><div class="col left"><p>Left Column Placeholder</p></div><div class="col"><p>Middle Column Placeholder</p></div><div class="two_col right"><p>Right Column Placeholder</p></div><br class="clear" /><div>Placeholder</div>');
			});
			ed.addCommand('mceUnlCol121', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div>Placeholder</div><div class="col left"><p>Left Column Placeholder</p></div><div class="two_col"><p>Middle Column Placeholder</p></div><div class="col right"><p>Right Column Placeholder</p></div><br class="clear" /><div>Placeholder</div>');
			});
			ed.addCommand('mceUnlCol211', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div>Placeholder</div><div class="two_col left"><p>Left Column Placeholder</p></div><div class="col"><p>Middle Column Placeholder</p></div><div class="col right"><p>Right Column Placeholder</p></div><br class="clear" /><div>Placeholder</div>');
			});
			ed.addCommand('mceUnlCol1111', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zenbox')) {
					return;
				}
				ed.selection.setContent('<div>Placeholder</div><div class="col left"><p>Left Column Placeholder</p></div><div class="col"><p>Middle Column Placeholder</p></div><div class="col"><p>Middle Column Placeholder</p></div><div class="col right"><p>Right Column Placeholder</p></div><br class="clear" /><div>Placeholder</div>');
			});

			// Placeholder div elements
			ed.addCommand('mceUnlPlaceholderAbovePrepend', function() {
				var curNode = ed.selection.getNode();
				WDN.jQuery(curNode).parent().prepend('<div>Placeholder</div>');
			});
			ed.addCommand('mceUnlPlaceholderAboveBefore', function() {
				var curNode = ed.selection.getNode();
				WDN.jQuery(curNode).parent().before('<div>Placeholder</div>');
			});
			ed.addCommand('mceUnlPlaceholderBelowAppend', function() {
				var curNode = ed.selection.getNode();
				WDN.jQuery(curNode).parent().append('<div>Placeholder</div>');
			});
			ed.addCommand('mceUnlPlaceholderBelowAfter', function() {
				var curNode = ed.selection.getNode();
				WDN.jQuery(curNode).parent().after('<br class="clear" /><div>Placeholder</div>');
			});

			// ZenTable
			ed.addCommand('mceUnlZenTableBright', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zentable')) {
					return;
				}
				ed.selection.setContent('<table class="zentable bright"><thead><tr><th colspan="3">zentable bright</th></tr></thead><tbody><tr><td>row1 col1</td><td>row1 col2</td><td>row1 col3</td></tr><tr><td>row2 col1</td><td>row2 col2</td><td>row2 col3</td></tr></tbody></table>');
			});
			ed.addCommand('mceUnlZenTableCool', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zentable')) {
					return;
				}
				ed.selection.setContent('<table class="zentable cool"><thead><tr><th colspan="3">zentable cool</th></tr></thead><tbody><tr><td>row1 col1</td><td>row1 col2</td><td>row1 col3</td></tr><tr><td>row2 col1</td><td>row2 col2</td><td>row2 col3</td></tr></tbody></table>');
			});
			ed.addCommand('mceUnlZenTableEnergetic', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zentable')) {
					return;
				}
				ed.selection.setContent('<table class="zentable energetic"><thead><tr><th colspan="3">zentable energetic</th></tr></thead><tbody><tr><td>row1 col1</td><td>row1 col2</td><td>row1 col3</td></tr><tr><td>row2 col1</td><td>row2 col2</td><td>row2 col3</td></tr></tbody></table>');
			});
			ed.addCommand('mceUnlZenTableSoothing', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zentable')) {
					return;
				}
				ed.selection.setContent('<table class="zentable soothing"><thead><tr><th colspan="3">zentable soothing</th></tr></thead><tbody><tr><td>row1 col1</td><td>row1 col2</td><td>row1 col3</td></tr><tr><td>row2 col1</td><td>row2 col2</td><td>row2 col3</td></tr></tbody></table>');
			});
			ed.addCommand('mceUnlZenTablePrimary', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zentable')) {
					return;
				}
				ed.selection.setContent('<table class="zentable primary"><thead><tr><th colspan="3">zentable primary</th></tr></thead><tbody><tr><td>row1 col1</td><td>row1 col2</td><td>row1 col3</td></tr><tr><td>row2 col1</td><td>row2 col2</td><td>row2 col3</td></tr></tbody></table>');
			});
			ed.addCommand('mceUnlZenTableNeutral', function() {
				if (Unl.hasParentNodeWithClass(ed.selection.getNode(), 'zentable')) {
					return;
				}
				ed.selection.setContent('<table class="zentable neutral"><thead><tr><th colspan="3">zentable neutral</th></tr></thead><tbody><tr><td>row1 col1</td><td>row1 col2</td><td>row1 col3</td></tr><tr><td>row2 col1</td><td>row2 col2</td><td>row2 col3</td></tr></tbody></table>');
			});

			// WDN Tabs
			ed.addCommand('mceUnlTabs', function() {
				ed.windowManager.open({
					file : url + '/tabs.htm',
					width : 350 + parseInt(ed.getLang('xhtmlxtras.abbr_delta_width', 0)),
					height : 250,
					inline : 1
				}, {
					plugin_url : url
				});
			});
			ed.addButton('unlTabs', {title : 'Add Tabs', cmd : 'mceUnlTabs', 'class' : 'unlTabs'});

			// WDN Tooltip
			ed.addCommand('mceUnlTooltip', function() {
				var node = ed.selection.getNode();
				if (Unl.hasParentNodeWithClass(node, 'tooltip')) {
				}
				ed.windowManager.open({
					file: url + '/tooltip.html',
					width: 500,
					height: 200,
					inline: 1
				});
			});

			// Add a node change handler, selects the button in the UI when a image is selected
			ed.onNodeChange.add(function(ed, cm, n) {
				cm.setActive('unlTooltip', Unl.hasParentNodeWithClass(n, 'tooltip'));
			});
			ed.addButton('unlTooltip', {title : 'Add Tooltip', cmd : 'mceUnlTooltip', 'class' : 'unlTooltip'});

			ed.addCommand('mceUnlEventMonthWidget', function() {
				ed.windowManager.open({
					file: url + '/event-monthwidget.html',
					width: 500,
					height: 200,
					inline: 1
				});
			});
			ed.onNodeChange.addToTop(function(ed, cm, n) {
				cm.setActive('unlEventMonthWidget', n.id == 'monthwidget');
				if (n.id == 'monthwidget') {
					ed.selection.select(n);
				}
			});
			ed.addButton('unlEventMonthWidget', {title: 'Add Month Widget', cmd : 'mceUnlEventMonthWidget', 'class' : 'unlEventMonthWidget'});

			ed.addCommand('mceUnlEventCalendarDisplay', function() {
				ed.windowManager.open({
					file: url + '/event-calendardisplay.html',
					width: 500,
					height: 200,
					inline: 1
				});
			});
			ed.onNodeChange.addToTop(function(ed, cm, n) {
				cm.setActive('unlEventCalendarDisplay', n.id == 'wdn_calendarDisplay');
				if (n.id == 'wdn_calendarDisplay') {
					ed.selection.select(n);
				}
			});
			ed.addButton('unlEventCalendarDisplay', {title: 'Add Calendar Display', cmd : 'mceUnlEventCalendarDisplay', 'class' : 'unlEventCalendarDisplay'});
		},

		/**
		 * Creates control instances based in the incomming name. This method is normally not
		 * needed since the addButton method of the tinymce.Editor class is a more easy way of adding buttons
		 * but you sometimes need to create more complex controls like listboxes, split buttons etc then this
		 * method can be used to create those.
		 *
		 * @param {String} n Name of the control to create.
		 * @param {tinymce.ControlManager} cm Control manager to use inorder to create new control.
		 * @return {tinymce.ui.Control} New control instance or null if no control was created.
		 */
		createControl: function(n, cm) {
			switch (n) {
				case 'unlZenBox':
					var c = cm.createSplitButton('unlZenBox', {
						title: 'Add Zen Box',
						'class' : 'unlZenBox',
						onclick: function() {
							this.control_manager.get('unlZenBox').showMenu();
						}
					});
					c.onRenderMenu.add(function(c, m) {
						m.add({title: 'UNL Zen Box', 'class' : 'mceMenuItemTitle'}).setDisabled(1);
						m.add({title: 'Bright (yellow)',	cmd: 'mceUnlZenBoxBright'});
						m.add({title: 'Cool (blue)',		cmd: 'mceUnlZenBoxCool'});
						m.add({title: 'Energetic (orange)',	cmd: 'mceUnlZenBoxEnergetic'});
						m.add({title: 'Soothing (green)',	cmd: 'mceUnlZenBoxSoothing'});
						m.add({title: 'Primary (red)',		cmd: 'mceUnlZenBoxPrimary'});
						m.add({title: 'Neutral (gray)',		cmd: 'mceUnlZenBoxNeutral'});
					});
					// Return the new splitbutton instance
					return c;

				case 'unlZenTable':
					var c = cm.createSplitButton('unlZenTable', {
						title: 'Add Zen Table',
						'class' : 'unlZenTable',
						onclick: function() {
							this.control_manager.get('unlZenTable').showMenu();
						}
					});
					c.onRenderMenu.add(function(c, m) {
						m.add({title: 'UNL Zen Table', 'class' : 'mceMenuItemTitle'}).setDisabled(1);
						m.add({title: 'Bright',		cmd: 'mceUnlZenTableBright'});
						m.add({title: 'Cool',		cmd: 'mceUnlZenTableCool'});
						m.add({title: 'Energetic',	cmd: 'mceUnlZenTableEnergetic'});
						m.add({title: 'Soothing',	cmd: 'mceUnlZenTableSoothing'});
						m.add({title: 'Primary',	cmd: 'mceUnlZenTablePrimary'});
						m.add({title: 'Neutral',	cmd: 'mceUnlZenTableNeutral'});
					});
					// Return the new splitbutton instance
					return c;

				case 'unlLayout':
					var c = cm.createSplitButton('unlLayout', {
						title: 'Add Layout',
						'class' : 'unlLayout',
						onclick: function() {
							this.control_manager.get('unlLayout').showMenu();
						}
					});
					c.onRenderMenu.add(function(c, m) {
						m.add({title: 'UNL Layouts', 'class': 'mceMenuItemTitle'}).setDisabled(1);
						m.add({title: 'Two Column (1/3)',		cmd: 'mceUnlCol13'});
						m.add({title: 'Two Column (2/2)',		cmd: 'mceUnlCol22'});
						m.add({title: 'Two Column (3/1)',		cmd: 'mceUnlCol31'});
						m.add({title: 'Three Column (1/1/2)',	cmd: 'mceUnlCol112'});
						m.add({title: 'Three Column (1/2/1)',	cmd: 'mceUnlCol121'});
						m.add({title: 'Three Column (2/1/1)',	cmd: 'mceUnlCol211'});
						m.add({title: 'Four Column (1/1/1/1)',	cmd: 'mceUnlCol1111'});
						m.add({title: 'Add Placeholder Above (Prepend)',	cmd: 'mceUnlPlaceholderAbovePrepend'});
						m.add({title: 'Add Placeholder Above (Before)',	cmd: 'mceUnlPlaceholderAboveBefore'});
						m.add({title: 'Add Placeholder Below (Append)',	cmd: 'mceUnlPlaceholderBelowAppend'});
						m.add({title: 'Add Placeholder Below (After)',	cmd: 'mceUnlPlaceholderBelowAfter'});
					});
					// Return the new splitbutton instance
					return c;
			}
			return null;
		},

		/**
		 * Returns information about the plugin as a name/value array.
		 * The current keys are longname, author, authorurl, infourl and version.
		 *
		 * @return {Object} Name/value array containing information about the plugin.
		 */
		getInfo : function() {
			return {
				longname : 'UNL plugin',
				author : 'UNL Web Developer Network',
				authorurl : 'http://tinymce.moxiecode.com',
				infourl : 'http://wiki.moxiecode.com/index.php/TinyMCE:Plugins/unl',
				version : "1.0"
			};
		}
	});

	// Register plugin
	tinymce.PluginManager.add('unl', tinymce.plugins.UnlPlugin);
})();